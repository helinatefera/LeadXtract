# YellowPagesScraper Desktop Application

This desktop application requires a license key for activation. The key is entered once through a simple graphical user interface (GUI) and saved for future use.

## Features

- User-friendly Tkinter GUI for key entry
- License key validation via API
- Persistent storage of the license key
